package com.vijayit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vijayit.config.OtpRequest;
import com.vijayit.config.OtpResponseDto;
import com.vijayit.config.OtpValidationRequest;
import com.vijayit.config.SmsService;
import com.vijayit.entity.LoginResponse;
import com.vijayit.entity.RegisterEntity;
import com.vijayit.service.RegisterService;

@RestController
@RequestMapping("/hms")
public class Registercontroller {

	@Autowired
	private RegisterService registerService;
	@Autowired
	private SmsService smsService;

	@PostMapping("/send")
	public OtpResponseDto sendOtp(@RequestBody OtpRequest otpRequest) {
		// log.info("inside send otp:" +otpRequest.getEmail());
		return smsService.sendSMS(otpRequest);
	}

	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestParam String otp) {
		// Validate OTP
		OtpValidationRequest otpValidationRequest = new OtpValidationRequest();
		otpValidationRequest.setOtpNumber(otp);
		String otpValidationResult = smsService.validateOtp(otpValidationRequest);

		if (otpValidationResult.equals("OTP Valid")) {
			RegisterEntity user = registerService.getUserByOtp(otp);

			if (user != null) {
				LoginResponse response = new LoginResponse();
				response.setUser(user);
				switch (user.getRole()) {
				case "doctor":
					response.setDashboardUrl("/doctor/dashboard");
					break;
				case "technician":
					response.setDashboardUrl("/technician/dashboard");
					break;
				case "units":
					response.setDashboardUrl("/units/dashboard");
					break;
				
				default:
					response.setDashboardUrl("/patient/dashboard");
					break;
				}
				return ResponseEntity.ok(response);
			} else {
				// User not found, return unauthorized status
				return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not found.");
			}
		} else {
			// OTP is not valid, return unauthorized status
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid OTP.");
		}
	}

//	 @PostMapping("/login")
//	    public ResponseEntity<LoginResponse> login(@RequestParam String email, @RequestParam String pwd) {
//	        RegisterEntity user = registerService.login(email, pwd);
//	        if (user != null) {
//	            LoginResponse response = new LoginResponse();
//	            response.setUser(user);
//	            switch (user.getRole()) {
//	                case "doctor":
//	                    response.setDashboardUrl("/doctor/dashboard");
//	                    break;
//	                case "technician":
//	                    response.setDashboardUrl("/technician/dashboard");
//	                    break;
//	                case "units":
//	                    response.setDashboardUrl("/units/dashboard");
//	                    break;
//	                default:
//	                    response.setDashboardUrl("/patient/dashboard");
//	                    break;
//	            }
//	            return ResponseEntity.ok(response);
//	        }
//	        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
//	    }

	@PostMapping("/save")
	public ResponseEntity<RegisterEntity> register(@RequestBody RegisterEntity registerEntity) {
		RegisterEntity savedEntity = registerService.save(registerEntity);
		if (savedEntity != null) {
			return ResponseEntity.status(HttpStatus.CREATED).body(savedEntity);
		} else {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}
}