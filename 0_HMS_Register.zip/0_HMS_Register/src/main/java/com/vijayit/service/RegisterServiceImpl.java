package com.vijayit.service;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vijayit.entity.RegisterEntity;
import com.vijayit.repo.RegisterRepo;
import com.vijayit.utility.EmailUtil;
import com.vijayit.utility.OtpUtils;

import jakarta.servlet.http.HttpSession;

@Service
public class RegisterServiceImpl implements RegisterService {
	@Autowired
	private RegisterRepo registerRepo;
	@Autowired
	private EmailUtil emailUtil;
	@Autowired
	private OtpUtils otpUtil;
	@Autowired
	private HttpSession session;

	@Override
	public RegisterEntity getUserByOtp(String otp) {

		return registerRepo.findByOtp(otp);
	}

	@Override
	public RegisterEntity login(String email, String pwd) {
		return registerRepo.findByEmailAndPwd(email, pwd);
	}

	@Override
	public RegisterEntity save(RegisterEntity entity) {

		String role = entity.getRole();
		String rolePrefix = getRolePrefix(role);

		String uniqueId = generateUniqueId(rolePrefix);
		entity.setPid(uniqueId);

		// Generate password
		String pwd = otpUtil.generatePwd();
		// Store password in entity
		entity.setPwd(pwd);

		RegisterEntity save = registerRepo.save(entity);

		if (save != null) {
			// Find the registered user by email
			RegisterEntity registeredUser = registerRepo.findByEmail(entity.getEmail());
			if (registeredUser != null) {
				// Generate PWD
				// String pwd = otpUtil.generatePwd();
				// Store PWD in session or wherever needed
				// session.setAttribute("resetOtp", pwd);

				String subject = "Automated Generated Password";
				String message = "Please Don't Share This PWD... This Is Confidential !! : " + pwd;
				emailUtil.sendEmail(registeredUser.getEmail(), subject, message);

				return save;
			} else {

				return null;
			}
		} else {

			return null;
		}
	}

	private String getRolePrefix(String role) {
		if ("units".equalsIgnoreCase(role)) {
			return "UNI";
		} else if ("doctor".equalsIgnoreCase(role)) {
			return "DOC";
		} else if ("admin".equalsIgnoreCase(role)) {
			return "ADM";
		} else if ("technician".equalsIgnoreCase(role)) {
			return "TEC";

		} else {
			// Default to "PAT" if role is empty or null
			return "PAT";
		}
	}

	private String generateUniqueId(String rolePrefix) {
		String randomNumbers = String.valueOf(new Random().nextInt(9000) + 1000);
		return rolePrefix + randomNumbers;
	}
}