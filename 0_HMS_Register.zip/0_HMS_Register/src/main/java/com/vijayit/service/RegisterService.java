package com.vijayit.service;

import com.vijayit.entity.RegisterEntity;

public interface RegisterService {
	
	public RegisterEntity getUserByOtp(String otp);
	public RegisterEntity save(RegisterEntity entity);
	public RegisterEntity login(String email, String pwd);

}
