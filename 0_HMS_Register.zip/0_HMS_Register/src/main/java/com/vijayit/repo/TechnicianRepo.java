package com.vijayit.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vijayit.entity.TechEntity;

public interface TechnicianRepo extends JpaRepository<TechEntity, String> {

}
