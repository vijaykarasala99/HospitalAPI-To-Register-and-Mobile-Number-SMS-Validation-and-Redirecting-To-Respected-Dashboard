package com.vijayit.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vijayit.entity.UnitEntity;

public interface UnitsRepo extends JpaRepository<UnitEntity, String>{

	
	
}
