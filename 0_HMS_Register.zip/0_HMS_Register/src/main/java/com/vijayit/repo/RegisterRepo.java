package com.vijayit.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vijayit.entity.RegisterEntity;
import java.util.List;


public interface RegisterRepo extends JpaRepository<RegisterEntity, String> {

	public RegisterEntity findByEmail(String email);
	
    public RegisterEntity findByEmailAndPwd(String email, String pwd);
    
    public RegisterEntity findByOtp(String otp);

}
