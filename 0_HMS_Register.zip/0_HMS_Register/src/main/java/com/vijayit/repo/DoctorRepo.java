package com.vijayit.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vijayit.entity.DoctorEntity;

public interface DoctorRepo extends JpaRepository<DoctorEntity, String> {

}
