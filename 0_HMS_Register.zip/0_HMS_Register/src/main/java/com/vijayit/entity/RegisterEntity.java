package com.vijayit.entity;

import java.time.LocalDate;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "patients")
public class RegisterEntity {

	@Id
	private String pid;
	private String firstName;
	private String lastName;

	@Column(unique = true)
	private String email;

	private String mobile;
	private Integer age;
	private LocalDate dob;
	private String gender;
	private String relationship;
	private String bloodGroup;
	private String familyDoctor;
	private String address;
	private boolean disclaimer;
	private String role;
	private String pwd;
	private String otp;

	
	
	
	public RegisterEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RegisterEntity(String pid, String firstName, String lastName, String email, String mobile, Integer age,
			LocalDate dob, String gender, String relationship, String bloodGroup, String familyDoctor, String address,
			boolean disclaimer, String role, String pwd, String otp) {
		super();
		this.pid = pid;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.mobile = mobile;
		this.age = age;
		this.dob = dob;
		this.gender = gender;
		this.relationship = relationship;
		this.bloodGroup = bloodGroup;
		this.familyDoctor = familyDoctor;
		this.address = address;
		this.disclaimer = disclaimer;
		this.role = role;
		this.pwd = pwd;
		this.otp = otp;
	}

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public String getFamilyDoctor() {
		return familyDoctor;
	}

	public void setFamilyDoctor(String familyDoctor) {
		this.familyDoctor = familyDoctor;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public boolean isDisclaimer() {
		return disclaimer;
	}

	public void setDisclaimer(boolean disclaimer) {
		this.disclaimer = disclaimer;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

}