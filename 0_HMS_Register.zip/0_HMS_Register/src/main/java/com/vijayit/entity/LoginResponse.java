package com.vijayit.entity;

public class LoginResponse {

	private RegisterEntity user;
	private String dashboardUrl;
	
	
	public LoginResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LoginResponse(RegisterEntity user, String dashboardUrl) {
		super();
		this.user = user;
		this.dashboardUrl = dashboardUrl;
	}
	public RegisterEntity getUser() {
		return user;
	}
	public void setUser(RegisterEntity user) {
		this.user = user;
	}
	public String getDashboardUrl() {
		return dashboardUrl;
	}
	public void setDashboardUrl(String dashboardUrl) {
		this.dashboardUrl = dashboardUrl;
	}
	
	
}
