package com.vijayit.config;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import com.vijayit.entity.RegisterEntity;
import com.vijayit.repo.RegisterRepo;


@Service
public class SmsService {
	@Autowired
	private TwilioConfig twilioConfig;

	@Autowired
	private RegisterRepo registerRepository;

	Map<String, String> otpMap = new HashMap<>();

	public OtpResponseDto sendSMS(OtpRequest opRequest) {
		OtpResponseDto otpResponseDto = null;
		try {
			// Fetch the user details by email from the database
			RegisterEntity user = registerRepository.findByEmail(opRequest.getEmail());

			if (user != null) {
				PhoneNumber to = new PhoneNumber(user.getMobile()); // Fetch phone number from user
				PhoneNumber from = new PhoneNumber(twilioConfig.getPhoneNumber());
				String otp = generateOtp();
				String otpMsg = "Dear Customer: " + "" + otp + " is Your OTP";
				Message msg = Message.creator(to, from, otpMsg).create();
				// Store the OTP in the database along with the user's email

				// RegisterEntity user = registerRepository.findByEmail(otpRequest.getEmail());
				if (user != null) {
					user.setOtp(otp);
					registerRepository.save(user);
				}

				otpMap.put(opRequest.getEmail(), otp);
				otpResponseDto = new OtpResponseDto(OtpStatus.DELIVERED, otpMsg);
			} else {
				otpResponseDto = new OtpResponseDto(OtpStatus.FAILED, "User not found");
			}
		} catch (Exception e) {
			e.printStackTrace();
			otpResponseDto = new OtpResponseDto(OtpStatus.FAILED, e.getMessage());
		}
		return otpResponseDto;
	}

	public String validateOtp(OtpValidationRequest otpValidate) {
		String expectedOtp = otpValidate.getOtpNumber();

		if (otpMap.containsValue(expectedOtp)) {
			// OTP is valid
			// Removing the OTP from the map after validation
			for (Iterator<Map.Entry<String, String>> it = otpMap.entrySet().iterator(); it.hasNext();) {
				Map.Entry<String, String> entry = it.next();
				if (entry.getValue().equals(expectedOtp)) {
					it.remove();
					break; // Exiting loop after removing the OTP
				}
			}
			return "OTP Valid";
		} else {
			// OTP is not valid
			return "Not Valid OTP";
		}
	}

	private String generateOtp() {
		return new DecimalFormat("000000").format(new Random().nextInt(999999));
	}
}
