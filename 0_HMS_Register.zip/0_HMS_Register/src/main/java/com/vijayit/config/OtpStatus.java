package com.vijayit.config;

public enum OtpStatus {
	
	DELIVERED , FAILED
	
}
