package com.vijayit.config;

public class OtpRequest {

	private String email;
	private String mobile;
	
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public OtpRequest(String email, String mobile) {
		super();
		this.email = email;
		this.mobile = mobile;
	}
	public OtpRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}