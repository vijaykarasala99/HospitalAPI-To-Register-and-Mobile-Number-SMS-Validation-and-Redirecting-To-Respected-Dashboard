package com.vijayit.config;

public class OtpValidationRequest {

private String otpNumber;
	

	public String getOtpNumber() {
		return otpNumber;
	}
	public void setOtpNumber(String otpNumber) {
		this.otpNumber = otpNumber;
	}
}
