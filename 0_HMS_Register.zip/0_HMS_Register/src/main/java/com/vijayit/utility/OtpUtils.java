package com.vijayit.utility;

import java.util.Random;

import org.springframework.stereotype.Component;

@Component
public class OtpUtils {

	public String generatePwd() {
	    Random random = new Random();
	    int pwd = 100000 + random.nextInt(900000);
	    return "HMS" + pwd;
	}

}
