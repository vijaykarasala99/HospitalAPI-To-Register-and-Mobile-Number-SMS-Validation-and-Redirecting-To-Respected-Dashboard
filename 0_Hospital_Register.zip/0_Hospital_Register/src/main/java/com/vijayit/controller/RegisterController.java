package com.vijayit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vijayit.config.OtpRequest;
import com.vijayit.config.OtpResponseDto;
import com.vijayit.config.OtpValidationRequest;
import com.vijayit.config.SmsService;
import com.vijayit.entity.LoginResponse;
import com.vijayit.entity.RegisterEntity;
import com.vijayit.service.RegisterService;

import lombok.extern.slf4j.Slf4j;


@RestController
public class RegisterController {

	@Autowired
	private RegisterService service;
	
	@Autowired
	private SmsService smsService;
	
	@PostMapping("/send")
	public OtpResponseDto sendOtp(@RequestBody OtpRequest otpRequest) {
		//log.info("inside send otp:"  +otpRequest.getEmail());
		return smsService.sendSMS(otpRequest);
	}
	

	
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestParam String otp) {
	    // Validate OTP
	    OtpValidationRequest otpValidationRequest = new OtpValidationRequest();
	    otpValidationRequest.setOtpNumber(otp);
	    String otpValidationResult = smsService.validateOtp(otpValidationRequest);

	    if (otpValidationResult.equals("OTP Valid")) {
	        RegisterEntity user = service.getUserByOtp(otp); 
	        
	        if (user != null) {
	            LoginResponse response = new LoginResponse();
	            response.setUser(user);
	            switch (user.getRole()) {
	                case "doctor":
	                    response.setDashboardUrl("/doctor/dashboard");
	                    break;
	                case "technician":
	                    response.setDashboardUrl("/technician/dashboard");
	                    break;
	                case "units":
	                    response.setDashboardUrl("/units/dashboard");
	                    break;
	                case "patient":
	                    response.setDashboardUrl("/patient/dashboard");
	                    break;
	                default:
	                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
	            }
	            return ResponseEntity.ok(response);
	        } else {
	            // User not found, return unauthorized status
	            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not found.");
	        }
	    } else {
	        // OTP is not valid, return unauthorized status
	        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid OTP.");
	    }
	}




	 
	
//	@PostMapping("/verify")
//	public String validate(@RequestBody OtpValidationRequest otpValidate) {
//		//log.info("inside send otp:"  +otpValidate.getEmail());
//		return smsService.validateOtp(otpValidate);
//	}
		 
@PostMapping("/save")
public RegisterEntity save(@RequestBody RegisterEntity entity) {
	return service.save(entity);
}
}	
