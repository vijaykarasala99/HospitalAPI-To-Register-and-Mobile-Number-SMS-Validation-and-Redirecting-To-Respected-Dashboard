package com.vijayit.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vijayit.config.SmsService;
import com.vijayit.entity.RegisterEntity;
import com.vijayit.repo.RegisterRepository;


@Service
public class RegisterServiceImpl implements RegisterService {

	@Autowired
	private RegisterRepository repo;
    
	@Autowired
	private SmsService smsService;

	@Override
	public RegisterEntity save(RegisterEntity entity) {
		return repo.save(entity);
	}

	@Override
	public RegisterEntity login(String email, String pwd) {
		return repo.findByEmailAndPwd(email, pwd);
	}

	@Override
	public RegisterEntity getUserByOtp(String otp) {
		// TODO Auto-generated method stub
		return repo.findByOtp(otp);
	}

}
