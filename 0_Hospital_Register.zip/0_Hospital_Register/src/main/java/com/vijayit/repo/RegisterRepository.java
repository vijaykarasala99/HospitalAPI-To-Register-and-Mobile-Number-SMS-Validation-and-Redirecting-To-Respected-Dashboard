package com.vijayit.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vijayit.entity.RegisterEntity;
import java.util.List;



public interface RegisterRepository extends JpaRepository<RegisterEntity, Long> {

	public RegisterEntity findByEmailAndPwd(String email, String pwd);

	public RegisterEntity findByEmail(String email);
	
	public RegisterEntity  findByOtp(String otp);
}
