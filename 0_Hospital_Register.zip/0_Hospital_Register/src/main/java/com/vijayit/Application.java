package com.vijayit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.twilio.Twilio;
import com.vijayit.config.TwilioConfig;

import jakarta.annotation.PostConstruct;

@EnableConfigurationProperties
@SpringBootApplication
public class Application {

	@Autowired
	private TwilioConfig twilioConfig;
	
	@PostConstruct
	public void setUp() {
		Twilio.init(twilioConfig.getAccountSid(),twilioConfig.getAuthToken());
	}
	
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

}
